package CodeForFuture.AutoCode.mapper;

import CodeForFuture.AutoCode.entity.Designepattern;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author AutoCode
 * @since 2018-10-20
 */
public interface DesignepatternMapper extends BaseMapper<Designepattern> {

}
