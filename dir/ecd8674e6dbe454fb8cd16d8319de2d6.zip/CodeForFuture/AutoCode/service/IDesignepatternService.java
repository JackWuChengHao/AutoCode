package CodeForFuture.AutoCode.service;

import CodeForFuture.AutoCode.entity.Designepattern;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author AutoCode
 * @since 2018-10-20
 */
public interface IDesignepatternService extends IService<Designepattern> {

}
