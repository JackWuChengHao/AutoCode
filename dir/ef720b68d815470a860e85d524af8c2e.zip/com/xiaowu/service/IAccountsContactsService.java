package com.xiaowu.service;

import com.xiaowu.entity.AccountsContacts;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author AutoCode
 * @since 2018-10-05
 */
public interface IAccountsContactsService extends IService<AccountsContacts> {

}
