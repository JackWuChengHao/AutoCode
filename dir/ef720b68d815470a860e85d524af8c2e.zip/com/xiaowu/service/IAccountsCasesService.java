package com.xiaowu.service;

import com.xiaowu.entity.AccountsCases;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author AutoCode
 * @since 2018-10-05
 */
public interface IAccountsCasesService extends IService<AccountsCases> {

}
