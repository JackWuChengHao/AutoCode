package com.xiaowu.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author AutoCode
 * @since 2018-10-05
 */
@RestController
@RequestMapping("/accountsContacts")
public class AccountsContactsController {

}

