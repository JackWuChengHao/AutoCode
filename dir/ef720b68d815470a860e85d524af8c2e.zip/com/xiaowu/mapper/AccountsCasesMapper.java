package com.xiaowu.mapper;

import com.xiaowu.entity.AccountsCases;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author AutoCode
 * @since 2018-10-05
 */
public interface AccountsCasesMapper extends BaseMapper<AccountsCases> {

}
