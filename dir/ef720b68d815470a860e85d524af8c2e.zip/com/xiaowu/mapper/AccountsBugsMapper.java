package com.xiaowu.mapper;

import com.xiaowu.entity.AccountsBugs;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author AutoCode
 * @since 2018-10-05
 */
public interface AccountsBugsMapper extends BaseMapper<AccountsBugs> {

}
